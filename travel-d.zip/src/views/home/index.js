import React from "react";
import Post from "ui-component/cards/Post";

const Home = () => {
  return (
    <div>
      <Post />
      <br />
      <Post />
    </div>
  );
};

export default Home;
