import { PostContext } from "context/PostContext";
import React from "react";
import { useEffect } from "react";
import { useContext } from "react";
import Post from "ui-component/cards/Post";

const Home = React.memo(() => {
  const { posts, loading, fetchData } = useContext(PostContext);
  useEffect(() => {
    fetchData();
  }, []);

  return (
    <>
      {posts.map((post) => (
        <Post post={post} key={post._id} />
      ))}
    </>
  );
});
export default Home;
