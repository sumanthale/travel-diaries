import { Typography } from "@mui/material";
import React, { useCallback } from "react";
import { useState } from "react";

import { Dropzone } from "./Dropzone";

function Drop({ user, setImages, images }) {
  // const [img, setImg] = useState([]);
  const onDrop = useCallback((acceptedFiles) => {
    acceptedFiles.forEach((file) => {
      setImages((prevState) => [...prevState, file]);
      // const reader = new FileReader();
      // reader.onload = function (e) {
      //   setImg((prevState) => [...prevState, { src: e.target.result }]);
      // };
      // reader.readAsDataURL(file);
    });
  }, []);

  return (
    <div className="drop">
      <Typography
        variant="h5"
        sx={{
          textAlign: "center",
        }}
        gutterBottom
      >
        Added {images.length} images to dropzone
      </Typography>
      <Dropzone onDrop={onDrop} />
    </div>
  );
}

export default Drop;
