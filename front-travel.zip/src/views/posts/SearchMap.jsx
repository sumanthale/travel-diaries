import * as React from "react";
import { Box } from "@mui/system";

export default function CustomizedInputBase() {
  return <Box sx={{}}></Box>;
}
