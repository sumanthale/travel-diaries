import React, { useRef } from "react";

const Image = ({ image }) => {
  const ref = useRef(null);

  // initialize drag and drop into the element

  return (
    <div ref={ref} className="file-item">
      <img alt={`img - ${image.id}`} src={image.src} className="file-img" />
    </div>
  );
};

const ImageList = ({ images, moveImage }) => {
  const renderImage = (image, index) => {
    return <Image image={image} key={`${image.id}-image`} />;
  };

  return <section className="file-list">{images.map(renderImage)}</section>;
};

export default ImageList;
