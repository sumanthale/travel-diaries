import * as React from "react";
import Card from "@mui/material/Card";
import CardHeader from "@mui/material/CardHeader";
import CardContent from "@mui/material/CardContent";
import CardActions from "@mui/material/CardActions";
import Avatar from "@mui/material/Avatar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import Images from "./ImagesCarousel";
import { Box, Button, Chip, Grid, Rating } from "@mui/material";
import { Stack } from "@mui/system";
import PlaceIcon from "@mui/icons-material/Place";
import dayjs from "dayjs";
import { AccessTime, Favorite, Star, StarOutline } from "@mui/icons-material";
var relativeTime = require("dayjs/plugin/relativeTime");

dayjs.extend(relativeTime);
export default function Post({ post }) {
  return (
    <Card sx={{ maxWidth: 960, margin: "auto", mb: 2 }}>
      <CardHeader
        sx={{
          px: 2,
          py: 2,
          pb: 1,
        }}
        avatar={
          <Avatar sx={{}} aria-label="recipe">
            R
          </Avatar>
        }
        action={
          <IconButton aria-label="settings">
            <MoreVertIcon />
          </IconButton>
        }
        title={post.user}
        subheader={`${dayjs(post.createdAt).fromNow()}`}
      />

      <Grid container>
        <Grid item xs={12} sm={5}>
          <Images images={post.images} />
        </Grid>
        <Grid item xs={12} sm={7}>
          <Box
            sx={{
              px: 2,
              pt: 1,
            }}
          >
            <Typography variant="h2" component="div">
              {post.title}
            </Typography>

            <Stack
              direction={"row"}
              sx={{
                alignItems: "center",
                my: 2,
              }}
              spacing={1}
            >
              <span
                className="rating-button"
                style={{
                  backgroundColor: `${findColor(post.rating)}`,
                }}
              >
                <span>{post.rating}.0</span>
                <Star
                  sx={{
                    fontSize: "14px",
                  }}
                />
              </span>
              {post.rating >= 4 && (
                <>
                  <span
                    style={{
                      backgroundColor: "#fcc",
                      padding: "3px",
                      borderRadius: "50%",
                      display: "flex",
                      justifyContent: "center",
                      alignItems: "center",
                    }}
                  >
                    <Favorite
                      sx={{
                        color: "#ff5d5d",
                        fontSize: "14px",
                      }}
                    />
                  </span>

                  <Typography>Recommended by 100% of travellers</Typography>
                </>
              )}
            </Stack>
            <Stack direction={"row"} sx={{ my: 2 }} spacing={1}>
              <Chip
                icon={<PlaceIcon />}
                label="Location 1, Location 2"
                variant="outlined"
                color="secondary"
              />
              <Chip
                icon={<AccessTime />}
                label="1 hour 30 min"
                variant="outlined"
                color="primary"
              />
            </Stack>
            <div
              className="truncate"
              dangerouslySetInnerHTML={{ __html: post.content }}
            />

            <Box
              sx={{ mt: 2, display: "flex", justifyContent: "space-between" }}
            >
              <Box>
                <Typography
                  component="span"
                  sx={{
                    fontSize: "35px",
                    fontWeight: "bold",
                    color: "#000",
                  }}
                >
                  ${Number(post.price)}.00
                </Typography>
                <Typography component="p" variant="body2">
                  per adult
                </Typography>
              </Box>
              <Box>
                <Button sx={{}} variant="outlined">
                  View Details
                </Button>
              </Box>
            </Box>
          </Box>
        </Grid>
      </Grid>
    </Card>
  );
}

const findColor = (color) => {
  switch (color) {
    case 1:
      return "#ff4545";
    case 2:
      return "#ffa534";
    case 3:
      return "#ffe234";
    case 4:
      return "#b7dd29";
    case 5:
      return "#57e32c";
    default:
      break;
  }
};
